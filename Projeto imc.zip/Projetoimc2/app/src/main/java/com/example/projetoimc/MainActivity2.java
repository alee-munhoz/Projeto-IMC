package com.example.projetoimc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView valorIMC, mensagem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        valorIMC = findViewById(R.id.txtValorIMC);
        mensagem = findViewById(R.id.txtMensagem);

        double imc = getIntent().getDoubleExtra("imc", 0);

        valorIMC.setText("IMC: " + String.format("%.1f", imc));

        if(imc < 18.5){
            mensagem.setText("Abaixo do peso");
        }
        else if(imc < 25){
            mensagem.setText("Peso normal");
        }
        else if(imc < 30){
            mensagem.setText("Sobrepeso");
        }
        else{
            mensagem.setText("Obesidade");
        }
    }

    public void voltar(View v){
        finish();
    }
}