package com.example.projetoimc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText nome, peso, altura;
    Button calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = findViewById(R.id.edtNome);
        peso = findViewById(R.id.edtPeso);
        altura = findViewById(R.id.edtAltura);
        calcular = findViewById(R.id.btnCalcular);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double p = Double.parseDouble(peso.getText().toString());
                double a = Double.parseDouble(altura.getText().toString());

                double imc = p / (a * a);

                Intent tela2 = new Intent(MainActivity.this, MainActivity2.class);
                tela2.putExtra("imc", imc);

                startActivity(tela2);
            }
        });
    }
}